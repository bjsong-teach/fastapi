#./app/main.py
from fastapi import FastAPI, Query, Depends, HTTPException, status
from typing import Optional, List
from sqlmodel import SQLModel, Field, create_engine, Session, select
#from app.database import create_db_and_tables, get_session
from database import engine


class Users(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str
    email: str 

app = FastAPI()

@app.on_event("startup")
def on_startup():
    SQLModel.metadata.create_all(engine)

# 샘플 데이터 초기화
@app.post("/users/init/")
def init_users():
    sample_users = [
        Users(name=f"User{i}", email=f"user{i}@example.com") for i in range(1, 21)
    ]
    with Session(engine) as session:
        for user in sample_users:
            session.add(user)
        session.commit()
    return {"message": "20 users initialized"}   

# 특정 사용자 조회 (ID로 한 명)
@app.get("/users/{id}", response_model=Users)
def read_user(id: int):
    with Session(engine) as session:  # 세션 열기
        user = session.get(Users, id)  # ID로 조회
        if not user:  # 없으면 404 에러
            raise HTTPException(status_code=404, detail="User not found")
        return user  # 사용자 반환 


@app.get("/users/all/", response_model=List[Users])
def read_all_users():
    with Session(engine) as session:  # 세션 열기
        statement = select(Users)
        users = session.exec(statement).all()
        return users
    
@app.get("/users/", response_model=List[Users])
def read_paging_users(page:int=Query(1,ge=1)):
    with Session(engine) as session:  # 세션 열기
        size = 10
        offset = (page-1)*size
        statement = select(Users).offset(offset).limit(size)
        users = session.exec(statement).all()
        return users
# 이제 FastAPI 애플리케이션에서 engine을 사용할 수 있습니다.
# ... FastAPI 앱 설정